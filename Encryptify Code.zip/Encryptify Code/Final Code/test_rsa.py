import requests
import base64
import os

# === Step 1: Read and Base64-encode the file ===
input_filename = 'Theoretical Foundations.pdf'  
with open(input_filename, 'rb') as f:
    file_bytes = f.read()

file_data_b64 = base64.b64encode(file_bytes).decode()

# === Step 2: Encrypt the file ===
encrypt_response = requests.post(
    'http://127.0.0.1:8000/rsa/encrypt/',
    json={'message': file_data_b64}
)

if encrypt_response.status_code != 200:
    print("❌ Encryption failed:", encrypt_response.text)
    exit()

encrypt_data = encrypt_response.json()

encrypted_file_b64 = encrypt_data['encrypted_file']
public_key_pem = encrypt_data['public_key']
private_key_pem = encrypt_data['private_key']

# === Step 3: Save encrypted file ===
encrypted_filename = 'encrypted_output.txt'
with open(encrypted_filename, 'wb') as f:
    f.write(base64.b64decode(encrypted_file_b64))

print(f"✅ Encrypted file saved as '{encrypted_filename}'")

# === Step 4: Save RSA keys ===
with open('public.pem', 'w') as f:
    f.write(public_key_pem)
with open('private.pem', 'w') as f:
    f.write(private_key_pem)

print("✅ Keys saved as 'public.pem' and 'private.pem'")

# === Step 5: Decrypt the file ===
decrypt_response = requests.post(
    'http://127.0.0.1:8000/rsa/decrypt/',
    json={
        'encrypted_message': encrypted_file_b64,
        'private_key': private_key_pem
    }
)

if decrypt_response.status_code != 200:
    print("❌ Decryption failed:", decrypt_response.text)
    exit()

decrypted_data_b64 = decrypt_response.json()['decrypted_message']
decrypted_bytes = base64.b64decode(decrypted_data_b64)

# === Step 6: Save decrypted file ===
file_extension = os.path.splitext(input_filename)[-1].lstrip('.')  
output_filename = f'decrypted_output.{file_extension}'
with open(output_filename, 'wb') as f:
    f.write(decrypted_bytes)

print(f"✅ Decrypted file saved as '{output_filename}'")
