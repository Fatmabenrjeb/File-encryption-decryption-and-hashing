import hashlib
from cryptography.hazmat.primitives import hashes, serialization
from cryptography.hazmat.primitives.asymmetric import padding, rsa
from cryptography.hazmat.backends import default_backend
import base64


def compute_hash(file):
    """Computes SHA-256 hash of a given file"""
    hash_sha256 = hashlib.sha256()
    with open(file, 'rb') as f:
        for chunk in iter(lambda: f.read(4096), b""):
            hash_sha256.update(chunk)
    return hash_sha256.hexdigest()


def generate_keys():
    """Generates RSA key pair"""
    private_key = rsa.generate_private_key(
        public_exponent=65537, key_size=2048, backend=default_backend()
    )
    public_key = private_key.public_key()

    # Serialize keys to PEM format
    private_pem = private_key.private_bytes(
        encoding=serialization.Encoding.PEM,
        format=serialization.PrivateFormat.PKCS8,
        encryption_algorithm=serialization.NoEncryption()
    )
    public_pem = public_key.public_bytes(
        encoding=serialization.Encoding.PEM,
        format=serialization.PublicFormat.SubjectPublicKeyInfo
    )
    return private_pem, public_pem


def sign_hash(hash_value, private_pem):
    """Signs the SHA-256 hash using the private key"""
    private_key = serialization.load_pem_private_key(
        private_pem, password=None, backend=default_backend()
    )
    signature = private_key.sign(
        hash_value.encode(),
        padding.PSS(mgf=padding.MGF1(hashes.SHA256()), salt_length=padding.PSS.MAX_LENGTH),
        hashes.SHA256()
    )
    return signature


def verify_signature(hash_value, signature, public_pem):
    """Verifies the digital signature using the public key"""
    public_key = serialization.load_pem_public_key(public_pem, backend=default_backend())
    try:
        public_key.verify(
            signature,
            hash_value.encode(),
            padding.PSS(mgf=padding.MGF1(hashes.SHA256()), salt_length=padding.PSS.MAX_LENGTH),
            hashes.SHA256()
        )
        return True
    except Exception as e:
        print("Verification failed:", e)
        return False


# Test with a sample file
file_path = 'hello fatma.txt'  # Replace with your actual file path

# Compute the hash
file_hash = compute_hash(file_path)
print("File Hash:", file_hash)

# Generate RSA keys
private_pem, public_pem = generate_keys()

# Sign the hash
signature = sign_hash(file_hash, private_pem)
print("Signature (Base64 Encoded):", base64.b64encode(signature).decode())

# Verify the signature
is_valid = verify_signature(file_hash, signature, public_pem)
print("Signature Valid:", is_valid)
