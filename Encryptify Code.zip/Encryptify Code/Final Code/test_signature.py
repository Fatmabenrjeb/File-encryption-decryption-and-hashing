from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives.asymmetric import padding, rsa
from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.backends import default_backend

# Generate RSA keys
def generate_keys():
    """Generates RSA key pair"""
    private_key = rsa.generate_private_key(
        public_exponent=65537, key_size=2048, backend=default_backend()
    )
    public_key = private_key.public_key()

    # Serialize keys to PEM format
    private_pem = private_key.private_bytes(
        encoding=serialization.Encoding.PEM,
        format=serialization.PrivateFormat.PKCS8,
        encryption_algorithm=serialization.NoEncryption()
    )
    public_pem = public_key.public_bytes(
        encoding=serialization.Encoding.PEM,
        format=serialization.PublicFormat.SubjectPublicKeyInfo
    )
    return private_pem, public_pem

# Sign the hash using the private key
def sign_hash(message, private_pem):
    """Signs a message using the private key"""
    private_key = serialization.load_pem_private_key(
        private_pem, password=None, backend=default_backend()
    )
    signature = private_key.sign(
        message.encode(),  # Message to be signed
        padding.PSS(mgf=padding.MGF1(hashes.SHA256()), salt_length=padding.PSS.MAX_LENGTH),
        hashes.SHA256()
    )
    return signature

# Verify the signature using the public key
def verify_signature(message, signature, public_pem):
    """Verifies the digital signature using the public key"""
    public_key = serialization.load_pem_public_key(public_pem, backend=default_backend())
    try:
        public_key.verify(
            signature,  # Signature to verify
            message.encode(),  # Original message
            padding.PSS(mgf=padding.MGF1(hashes.SHA256()), salt_length=padding.PSS.MAX_LENGTH),
            hashes.SHA256()
        )
        return True
    except Exception:
        return False

# Test the Digital Signature process
if __name__ == '__main__':
    # Sample message
    message = "This is a test message."

    # Generate RSA keys
    private_pem, public_pem = generate_keys()

    # Sign the message
    signature = sign_hash(message, private_pem)
    print("Signature:", signature)

    # Verify the signature
    is_valid = verify_signature(message, signature, public_pem)
    print("Is the signature valid?", is_valid)
