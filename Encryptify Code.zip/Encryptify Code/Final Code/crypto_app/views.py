from django.shortcuts import render

from django.http import JsonResponse
from django.views.decorators.csrf import csrf_exempt
from Crypto.Cipher import AES
from Crypto.Random import get_random_bytes
import base64
import json


def pad(data):
    while len(data) % 16 != 0:
        data += ' '
    return data

def home(request):
    return render(request, 'frontend.html')

from Crypto.Util.Padding import pad  

@csrf_exempt  
def encrypt_message(request):
    if request.method == 'POST':
        try:
            body = json.loads(request.body)
            file_data_b64 = body.get('file_data')

            if not file_data_b64:
                return JsonResponse({'error': 'Missing file_data'}, status=400)

            file_bytes = base64.b64decode(file_data_b64)

            key = get_random_bytes(16)
            cipher = AES.new(key, AES.MODE_ECB)

            
            padded_data = pad(file_bytes, AES.block_size)

            encrypted = cipher.encrypt(padded_data)

            encrypted_b64 = base64.b64encode(encrypted).decode()
            key_b64 = base64.b64encode(key).decode()

            return JsonResponse({
                'encrypted_message': encrypted_b64,
                'key': key_b64
            })

        except Exception as e:
            return JsonResponse({'error': str(e)}, status=400)

    return JsonResponse({'message': 'Send a POST request with {"message": "your text"}'})


from Crypto.Util.Padding import unpad

@csrf_exempt
def decrypt_message(request):
    if request.method == 'POST':
        try:
            encrypted_b64 = request.POST.get('encrypted_message')
            key_file = request.FILES.get('key_file')

            if not encrypted_b64 or not key_file:
                return JsonResponse({'error': 'Missing encrypted_message or key_file'}, status=400)

            encrypted = base64.b64decode(encrypted_b64)
            key_b64 = key_file.read().decode('utf-8').strip()
            key = base64.b64decode(key_b64)

            cipher = AES.new(key, AES.MODE_ECB)
            decrypted = cipher.decrypt(encrypted)
            decrypted = unpad(decrypted, AES.block_size)

            decrypted_b64 = base64.b64encode(decrypted).decode('utf-8')
            return JsonResponse({'decrypted_message': decrypted_b64})

        except Exception as e:
            return JsonResponse({'error': f'Decryption failed: {str(e)}'}, status=400)

    return JsonResponse({'message': 'Use POST with multipart/form-data: encrypted_message (base64), key_file (file)'})



from rest_framework.decorators import api_view
from rest_framework.response import Response
from django.http import JsonResponse
from django.views.decorators.csrf import csrf_exempt
from Crypto.PublicKey import RSA
from Crypto.Cipher import PKCS1_OAEP
import base64
import json


def generate_rsa_keys():
    key = RSA.generate(2048) 
    private_key = key.export_key()  
    public_key = key.publickey().export_key()  
    return public_key, private_key


def encrypt_rsa(public_key, plaintext):
    key = RSA.import_key(public_key) 
    cipher = PKCS1_OAEP.new(key)  
    encrypted = cipher.encrypt(plaintext.encode()) 
    return encrypted

@csrf_exempt
@api_view(['POST'])
def encrypt_rsa(request):
    try:
        file_data = request.data.get('message')
        file_bytes = base64.b64decode(file_data.encode('utf-8'))

       
        key = RSA.generate(2048)
        public_key = key.publickey()
        cipher_rsa = PKCS1_OAEP.new(public_key)

        
        chunk_size = 190  
        encrypted_chunks = []

        for i in range(0, len(file_bytes), chunk_size):
            chunk = file_bytes[i:i + chunk_size]
            encrypted_chunk = cipher_rsa.encrypt(chunk)
            encrypted_chunks.append(encrypted_chunk)

        encrypted_data = b''.join(encrypted_chunks)
        encrypted_b64 = base64.b64encode(encrypted_data).decode('utf-8')

        return Response({
            'encrypted_file': encrypted_b64,
            'public_key': key.publickey().export_key().decode('utf-8'),
            'private_key': key.export_key().decode('utf-8'),
        })

    except Exception as e:
        return Response({'error': str(e)}, status=500)




@csrf_exempt
def decrypt_rsa(request):
    if request.method == 'POST':
        try:
            body = json.loads(request.body)
            encrypted_b64 = body.get('encrypted_message')
            private_key_b64 = body.get('private_key')

            if not encrypted_b64 or not private_key_b64:
                return JsonResponse({'error': 'Missing encrypted data or private key'}, status=400)

            encrypted_data = base64.b64decode(encrypted_b64)
            private_key = RSA.import_key(private_key_b64)
            cipher_rsa = PKCS1_OAEP.new(private_key)

            
            chunk_size = 256  
            decrypted_chunks = []

            for i in range(0, len(encrypted_data), chunk_size):
                chunk = encrypted_data[i:i+chunk_size]
                decrypted_chunks.append(cipher_rsa.decrypt(chunk))

            decrypted_data = b''.join(decrypted_chunks)

            return JsonResponse({
                'decrypted_message': base64.b64encode(decrypted_data).decode()
            })

        except Exception as e:
            return JsonResponse({'error': str(e)}, status=500)

    return JsonResponse({'message': 'POST request required'})





# hashing + digital signature
from django.shortcuts import render
from .forms import FileUploadForm
from .utils.hashing import compute_hash, generate_keys, sign_hash, verify_signature
import base64
import hashlib

@csrf_exempt
def hash_file(request):
    if request.method == 'POST':
        try:
            body = json.loads(request.body)
            file_data = body.get('file_data')

            if not file_data:
                return JsonResponse({'error': 'Missing file data'}, status=400)

            file_bytes = base64.b64decode(file_data)
            file_hash = hashlib.sha256(file_bytes).hexdigest()

            return JsonResponse({'hash': file_hash})

        except Exception as e:
            return JsonResponse({'error': str(e)}, status=500)

    return JsonResponse({'message': 'Use POST with file_data in Base64'})

from Crypto.PublicKey import RSA
from Crypto.Signature import pkcs1_15
from Crypto.Hash import SHA256

@csrf_exempt
def sign_file(request):
    if request.method == 'POST':
        try:
            body = json.loads(request.body)
            file_data = body.get('file_data')

            if not file_data:
                return JsonResponse({'error': 'Missing file_data'}, status=400)          

            file_bytes = base64.b64decode(file_data)
            file_hash = SHA256.new(file_bytes)

            key = RSA.generate(2048)
            private_key = key.export_key()
            public_key = key.publickey().export_key()

            signature = pkcs1_15.new(key).sign(file_hash)

            return JsonResponse({
                'signature': base64.b64encode(signature).decode(),
                'private_key': private_key.decode(),
                'public_key': public_key.decode()
            })

        except Exception as e:
            return JsonResponse({'error': str(e)}, status=500)

    return JsonResponse({'message': 'Use POST with {file_data: base64_string}'})



@csrf_exempt
def verify_signature(request):
    if request.method == 'POST':
        try:
            original_data_b64 = request.POST.get('original_file')
            signature_b64 = request.POST.get('signature')
            public_key_file = request.FILES.get('public_key_file')

            if not original_data_b64 or not signature_b64 or not public_key_file:
                return JsonResponse({'error': 'Missing data for verification'}, status=400)

            original_bytes = base64.b64decode(original_data_b64)
            signature = base64.b64decode(signature_b64)
            public_key = RSA.import_key(public_key_file.read())

            file_hash = SHA256.new(original_bytes)

            try:
                pkcs1_15.new(public_key).verify(file_hash, signature)
                return JsonResponse({'valid': True})
            except (ValueError, TypeError) as e:
                return JsonResponse({'valid': False, 'error': str(e)})

        except Exception as e:
            return JsonResponse({'error': str(e)}, status=500)

    return JsonResponse({'message': 'Use POST with original_file, signature, and public_key_file'})
    
