from django.urls import path
from . import views

urlpatterns = [
    path('', views.home, name='home'),  
    
    # AES Encryption 
    path('encrypt/', views.encrypt_message, name='encrypt'),
    
    #aes decryption
    path('decrypt/', views.decrypt_message, name='decrypt'),  
    
    # RSA encryption and decryption
    path('rsa/encrypt/', views.encrypt_rsa, name='encrypt_rsa'),
    path('rsa/decrypt/', views.decrypt_rsa, name='decrypt_rsa'),
    
    #hash
    path('hash/', views.hash_file, name='hash_file'),
    
    #signature
    path('signature/sign/', views.sign_file, name='sign_file'),
    path('signature/verify/', views.verify_signature, name='verify_signature'),
]