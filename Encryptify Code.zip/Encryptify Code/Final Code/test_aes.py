import requests
import base64
import os


input_filename = 'cat.jpg'
with open(input_filename, 'rb') as f:
    file_bytes = f.read()

file_data_b64 = base64.b64encode(file_bytes).decode()


encrypt_response = requests.post(
    'http://127.0.0.1:8000/encrypt/',
    json={'file_data': file_data_b64}
)

if encrypt_response.status_code != 200:
    print("❌ Encryption failed:", encrypt_response.text)
    exit()

encrypt_data = encrypt_response.json()
encrypted_file_b64 = encrypt_data['encrypted_message']
aes_key_b64 = encrypt_data['key']


encrypted_filename = 'encrypted_output.txt'
with open(encrypted_filename, 'wb') as f:
    f.write(base64.b64decode(encrypted_file_b64))

print(f"✅ Encrypted file saved as '{encrypted_filename}'")


with open('symmetric key.txt', 'w') as f:
    f.write(aes_key_b64)

print("✅ AES key saved as 'symmetric key.txt'")


with open('symmetric key.txt', 'rb') as key_file:
    decrypt_response = requests.post(
        'http://127.0.0.1:8000/decrypt/',
        data={'encrypted_message': encrypted_file_b64},
        files={'key_file': key_file}
    )

if decrypt_response.status_code != 200:
    print("❌ Decryption failed:", decrypt_response.text)
    exit()

decrypted_data_b64 = decrypt_response.json()['decrypted_message']
decrypted_bytes = base64.b64decode(decrypted_data_b64)


file_extension = os.path.splitext(input_filename)[-1].lstrip('.')
output_filename = f'decrypted_output.{file_extension}'
with open(output_filename, 'wb') as f:
    f.write(decrypted_bytes)

print(f"✅ Decrypted file saved as '{output_filename}'")
