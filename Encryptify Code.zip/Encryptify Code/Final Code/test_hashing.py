import hashlib

def compute_hash(file):
    """Computes SHA-256 hash of a given file"""
    hash_sha256 = hashlib.sha256()
    with open(file, 'rb') as f:
        for chunk in iter(lambda: f.read(4096), b""):
            hash_sha256.update(chunk)
    return hash_sha256.hexdigest()

# Test with a sample file
file_path = 'hello fatma.txt'  # Replace with your actual file path

# Compute the hash
file_hash = compute_hash(file_path)
print("File Hash (SHA-256):", file_hash)
